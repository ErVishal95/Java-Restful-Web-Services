package GeoLocate;

import org.codehaus.jackson.annotate.JsonProperty;

public class LatLon {
	
	@JsonProperty
	double Lat1;
	@JsonProperty
	double Lon1;
	@JsonProperty
	double Lat2;
	@JsonProperty
	double Lon2;
	
	/*public LatLon(double lat1, double lon1, double lat2, double lon2) {
		super();
		Lat1 = lat1;
		Lon1 = lon1;
		Lat2 = lat2;
		Lon2 = lon2;
	}*/
	public double getLat1() {
		return Lat1;
	}
	public void setLat1(double lat1) {
		Lat1 = lat1;
	}
	public double getLon1() {
		return Lon1;
	}
	public void setLon1(double lon1) {
		Lon1 = lon1;
	}
	public double getLat2() {
		return Lat2;
	}
	public void setLat2(double lat2) {
		Lat2 = lat2;
	}
	public double getLon2() {
		return Lon2;
	}
	public void setLon2(double lon2) {
		Lon2 = lon2;
	}
	
	
}
