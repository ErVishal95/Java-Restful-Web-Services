package GeoLocate;

import java.util.ArrayList;

public class GeoPoints {
	
	ArrayList<LatLon> array = new ArrayList<LatLon>();
	ArrayList<ReferencePoint> referencePoint = new ArrayList<ReferencePoint>();
	public double distanceKM;
	
	
	public ArrayList<LatLon> getArray() {
		return array;
	}

	public void setArray(ArrayList<LatLon> array) {
		this.array = array;
	}

	public ArrayList<ReferencePoint> getReferencePoint() {
		return referencePoint;
	}

	public void setReferencePoint(ArrayList<ReferencePoint> referencePoint) {
		this.referencePoint = referencePoint;
	}

	public double getDistanceKM() {
		return distanceKM;
	}

	public void setDistanceKM(double distanceKM) {
		this.distanceKM = distanceKM;
	}

	
	
	
}
