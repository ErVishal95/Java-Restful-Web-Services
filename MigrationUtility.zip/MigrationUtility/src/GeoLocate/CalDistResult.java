package GeoLocate;

import java.util.ArrayList;

public class CalDistResult {
	
	ArrayList<PositionVO> Distancefatched = new ArrayList<PositionVO>();
	ArrayList<PositionVOGeoPoint> result = new ArrayList<PositionVOGeoPoint>();
	public ArrayList<PositionVO> getDistancefatched() {
		return Distancefatched;
	}

	public void setDistancefatched(ArrayList<PositionVO> distancefatched) {
		Distancefatched = distancefatched;
	}

	public ArrayList<PositionVOGeoPoint> getResult() {
		return result;
	}

	public void setResult(ArrayList<PositionVOGeoPoint> result) {
		this.result = result;
	}
	
	
}
