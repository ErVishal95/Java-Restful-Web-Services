package com.newgen.rest.service;

import java.io.File;
import java.io.IOException;
import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.apache.log4j.Logger;
import org.jdom2.Document;
import org.jdom2.Element;
import org.jdom2.input.SAXBuilder;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;

import oracle.net.aso.f;

public class ExportScriptTableName {
	static Logger log = Logger.getLogger(ExportScriptTableName.class.getName());
	public static ArrayList<String> RelationPrase(File file) {
	
		//File file=new File("C:/NEWGEN OmniOMS/OmniOMS Designer/Relation/equitas_oracle/0023/0001/Relation.xml");
		ArrayList<String> faultlist = null;
		System.setProperty("javax.xml.parsers.SAXParserFactory", "com.sun.org.apache.xerces.internal.jaxp.SAXParserFactoryImpl");
		Document doc=null;
		SAXBuilder saxBuilder=new SAXBuilder();
		ArrayList<String> Tablenames=new ArrayList<String>();
        try {
        	doc = saxBuilder.build(file);
        	Element rootElement = doc.getRootElement();
    		Element Tables = rootElement.getChild("Tables");
    		List<Element> childNodes = Tables.getChildren();
			int childNodeSize = childNodes.size();
			for (int i = 0; i < childNodeSize; i++) {
		
				List<Element> TableName= childNodes.get(i).getChildren("TableName");
				int TableNodeSize = TableName.size();
				for (int j = 0; j < TableNodeSize; j++) {
					String name=TableName.get(j).getValue();
					name=name.substring(name.indexOf(".")+1, name.length());
					Tablenames.add(name);
				System.out.println("Table Name to Be checked is "+name);
				log.info("Table Name to Be checked is "+name);
				
				}
			}

        	System.out.println(childNodeSize);
        	//System.out.println(Tablenames);
        	 faultlist=TestTable.Tabletester(Tablenames);
        	
        } catch (Exception e1) {
            e1.printStackTrace();
        }
        return Tablenames;

    }


	}


