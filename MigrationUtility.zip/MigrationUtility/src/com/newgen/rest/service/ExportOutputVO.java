package com.newgen.rest.service;

public class ExportOutputVO {
String output;

public String getOutput() {
	return output;
}

public void setOutput(String output) {
	this.output = output;
}

}
