package com.newgen.rest.service;

public class testimport {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
TemplateImportVO tvo= new TemplateImportVO();
tvo.setFolderPath("");
	}

}
