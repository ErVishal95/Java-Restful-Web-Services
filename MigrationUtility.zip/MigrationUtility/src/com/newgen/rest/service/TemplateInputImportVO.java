package com.newgen.rest.service;

public class TemplateInputImportVO {
	String FolderPath;
	String[] productNameArray;

	

	public String[] getProductNameArray() {
		return productNameArray;
	}

	public void setProductNameArray(String[] productNameArray) {
		this.productNameArray = productNameArray;
	}
	
	

	public String getFolderPath() {
		return FolderPath;
	}

	public void setFolderPath(String folderPath) {
		FolderPath = folderPath;
	} 

}
