package com.newgen.rest.service;


import java.util.ArrayList;

public class MigrationOutputVO {
	ArrayList<Success> SuccessList = new ArrayList<Success>();
	public ArrayList<Success> getSuccessList() {
		return SuccessList;
	}
	public void setSc(ArrayList<Success> SuccessList) {
		SuccessList = SuccessList;
	}
	public ArrayList<Failure> getFailureList() {
		return FailureList;
	}
	public void setFl(ArrayList<Failure> FailureList) {
		FailureList = FailureList;
	}
	ArrayList<Failure> FailureList=new ArrayList<Failure>();
	

}
