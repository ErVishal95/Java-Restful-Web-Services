package com.newgen.rest.service;

import java.lang.reflect.Array;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.ArrayList;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.newgen.pdfgeneration.webservice.util.OMSODPdfSrvcPropFrmClsPth;



public class ConnectionManager {
	
	static Logger log = Logger.getLogger(ConnectionManager.class.getName());
	
	public static Connection getConnection(String user,String Password ,String metaDatabaseIP,String metaDatabasePort,String metaDatabaseServiceName ) throws ClassNotFoundException{
		Class.forName("oracle.jdbc.driver.OracleDriver");
		log.info("Class Loaded");
		//String metaDatabaseIP = PropertyFileEditor.getProperty("METADATABASEIP");
		//String metaDatabasePort = PropertyFileEditor.getProperty("METADATABASEPORT");
		//String metaDatabaseServiceName = PropertyFileEditor.getProperty("METADATABASESERVICENAME");
		String connectionUrl = "jdbc:oracle:thin:@" + metaDatabaseIP + ":" + metaDatabasePort + "/" + metaDatabaseServiceName;
		log.info("Connection url is "+connectionUrl);
		//String url = "jdbc:oracle:thin:@192.168.55.121:1521/pdborcl";
        Connection conn = null;
		try {
		//	String userName = PropertyFileEditor.getProperty("METADATABASEUSERNAME");
		//	String userPassword = PropertyFileEditor.getProperty("METADATABASEPASSWORD");
			Properties information = new Properties();
		    information.put("user", user);
		    information.put("password", Password);
			conn = DriverManager.getConnection(connectionUrl,information);
			}
		catch(Exception ex){
			log.error("Error while getting db connection " , ex);
			ex.printStackTrace();
		}
		return conn;
	}
	
public static void main(String[] args) {
	String user, Password, metaDatabaseIP, metaDatabasePort, metaDatabaseServiceName;
	user=OMSODPdfSrvcPropFrmClsPth.getProperty("DBUser");
	Password=OMSODPdfSrvcPropFrmClsPth.getProperty("DBPassword");
	metaDatabaseIP=OMSODPdfSrvcPropFrmClsPth.getProperty("DBIP");
	metaDatabasePort=OMSODPdfSrvcPropFrmClsPth.getProperty("DBport");
	metaDatabaseServiceName=OMSODPdfSrvcPropFrmClsPth.getProperty("ServiceName");
	ArrayList<String>  array = new ArrayList<>();
	array.add("asdasd");
	System.out.println(array);
	
	try {
		ConnectionManager.getConnection(user, Password, metaDatabaseIP, metaDatabasePort, metaDatabaseServiceName);
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
}

}
