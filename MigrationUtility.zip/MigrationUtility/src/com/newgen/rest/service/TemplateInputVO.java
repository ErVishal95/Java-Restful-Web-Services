package com.newgen.rest.service;

import java.util.ArrayList;

public class TemplateInputVO {

	
	static String[] productNameArray;

	

	public String[] getProductNameArray() {
		return productNameArray;
	}

	public void setProductNameArray(String[] productNameArray) {
		this.productNameArray = productNameArray;
	}
	
	
	
		
	
}
