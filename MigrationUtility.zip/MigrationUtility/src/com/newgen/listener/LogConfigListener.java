package com.newgen.listener;

import java.io.File;
import java.util.Enumeration;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.http.HttpServlet;

import org.apache.log4j.Appender;
import org.apache.log4j.Level;
import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.apache.log4j.PatternLayout;
import org.apache.log4j.RollingFileAppender;
import org.apache.log4j.SimpleLayout;

import com.newgen.inviewfo.constants.IAppConfigConstants;
import com.newgen.pdfgeneration.webservice.util.OMSODPdfSrvcPropFrmClsPth;

public final class LogConfigListener extends HttpServlet implements ServletContextListener, IAppConfigConstants {
	private static final long serialVersionUID = 1L;
	private static Logger logger = Logger.getLogger(LogConfigListener.class);

	@SuppressWarnings("unchecked")
	public final void contextInitialized(ServletContextEvent event) {
		final String METHOD_NAME = "contextInitialized";
		System.out.println(METHOD_NAME + " Execution started Successfully!");
		String logLocation = null;
		String logLevel = null;
		String maxLogFileSize = null;
		String appenderName = null;
		String setAppend = null;
		String encoding = null;
		String maxBackUpIndex = null;
		String conversionPattern = null;
		String packageToLog = null;
		try {
			// Getting Logging configuration related things from Property File
			// logLocation =
			// OMSODPdfSrvcPropFrmClsPth.getProperty("LOG_PATH").trim();
			logLocation = System.getProperty("user.dir") + File.separator + "OMS_Logs" + File.separator
					+ "CCMServiceLogs" + File.separator + "log.out";
			logLevel = OMSODPdfSrvcPropFrmClsPth.getProperty("LOG_LEVEL").trim();
			maxLogFileSize = OMSODPdfSrvcPropFrmClsPth.getProperty("LOG_MAXLOG_FILESIZE").trim();
			appenderName = OMSODPdfSrvcPropFrmClsPth.getProperty("LOG_APPENDER_NAME").trim();
			setAppend = OMSODPdfSrvcPropFrmClsPth.getProperty("LOG_SETAPPEND").trim();
			encoding = OMSODPdfSrvcPropFrmClsPth.getProperty("LOG_ENCODING").trim();
			maxBackUpIndex = OMSODPdfSrvcPropFrmClsPth.getProperty("LOG_MAXBACKUP_INDEX").trim();
			conversionPattern = OMSODPdfSrvcPropFrmClsPth.getProperty("LOG_CONVERSION_PATTERN").trim();
			packageToLog = OMSODPdfSrvcPropFrmClsPth.getProperty("LOG_PACKAGE_TO_LOG").trim();

			System.out.println(METHOD_NAME + "Configuring log file at location:" + logLocation + " with Log level:"
					+ logLevel + ", maxLogFileSize:" + maxLogFileSize + ", appenderName:" + appenderName + ",setAppend:"
					+ setAppend + ",encoding:" + encoding + ",maxBackUpIndex:" + maxBackUpIndex + ",conversionPattern:"
					+ conversionPattern + ",packageToLog:" + packageToLog);

			SimpleLayout layout = new SimpleLayout();

			RollingFileAppender rollingFileAppender = new RollingFileAppender(layout, logLocation, true);
			rollingFileAppender.setName(appenderName);
			rollingFileAppender.setAppend(Boolean.valueOf(setAppend));
			rollingFileAppender.setEncoding(encoding);
			rollingFileAppender.setMaxFileSize(maxLogFileSize);
			rollingFileAppender.setMaxBackupIndex(Integer.valueOf(maxBackUpIndex));

			PatternLayout patternLayout = new PatternLayout();
			patternLayout.setConversionPattern(conversionPattern);
			rollingFileAppender.setLayout(patternLayout);

			Logger logger = Logger.getLogger(packageToLog);

			// Setting the Log Level for Logging
			if (logLevel != null && !"".equalsIgnoreCase(logLevel)) {
				if (logLevel.equalsIgnoreCase(LOGLEVEL_INFO)) {
					logger.setLevel((Level) Level.INFO);
				} else if (logLevel.equalsIgnoreCase(LOGLEVEL_DEBUG)) {
					logger.setLevel((Level) Level.DEBUG);
				} else if (logLevel.equalsIgnoreCase(LOGLEVEL_WARN)) {
					logger.setLevel((Level) Level.WARN);
				} else if (logLevel.equalsIgnoreCase(LOGLEVEL_ERROR)) {
					logger.setLevel((Level) Level.ERROR);
				} else if (logLevel.equalsIgnoreCase(LOGLEVEL_FATAL)) {
					logger.setLevel((Level) Level.FATAL);
				} else if (logLevel.equalsIgnoreCase(LOGLEVEL_ALL)) {
					logger.setLevel((Level) Level.ALL);
				} else if (logLevel.equalsIgnoreCase(LOGLEVEL_OFF)) {
					logger.setLevel((Level) Level.OFF);
				}
			}
			logger.setAdditivity(false);
			logger.addAppender(rollingFileAppender);
			logger.info(METHOD_NAME + " Logging Configuration Done Successfully  For the Application");
		} catch (Exception exception) {
			String stackTrace = exception.toString();
			System.out.println(
					METHOD_NAME + " Exception catched in Exception Block with exception raised as::" + stackTrace);
		} catch (Throwable ex) {
			ex.printStackTrace();
			System.out.println(
					METHOD_NAME + " Exception catched in Throwable Block with exception raised as::" + ex.getMessage());
		}
	}

	@SuppressWarnings("unchecked")
	public void contextDestroyed(ServletContextEvent event) {
		final String METHOD_NAME = "contextDestroyed";
		try {
			for (Enumeration enumeration = logger.getAllAppenders(); enumeration.hasMoreElements();) {
				Appender appender = (Appender) enumeration.nextElement();
				appender.close();
			}
			LogManager.shutdown();
			logger = null;
		} catch (Exception exception) {
			String stackTrace = exception.toString();
			System.out.println(
					METHOD_NAME + " Exception catched in Exception Block with exception raised as::" + stackTrace);
		}
	}
}
