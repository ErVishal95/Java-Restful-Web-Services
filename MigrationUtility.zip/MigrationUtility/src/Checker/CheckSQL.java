package Checker;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Properties;

import org.apache.log4j.Logger;

import com.newgen.rest.service.ConnectionManager;
import com.newgen.rest.service.property;

public class CheckSQL {
	
	public static void main(String args[]) throws ClassNotFoundException, SQLException{
		// TODO Auto-generated method stub
	//	MigrationOutputVO mvo = new MigrationOutputVO();
		Properties prop = new Properties();
		InputStream input = null;
		String Key = null;
		ArrayList<String> faultlist = new ArrayList<String>();
		try {

			String filename = "abc.properties";
			input = property.class.getClassLoader().getResourceAsStream(filename);
			if (input == null) {
				//log.info("Sorry, unable to find " + filename);
		
			}

			prop.load(input);

		} catch (IOException ex) {
			ex.printStackTrace();
		
		} finally {
			if (input != null) {
				try {
					input.close();
				} catch (IOException e) {
					//e.printStackTrace();
				
				}
			}
		}
		String DBIP = prop.getProperty("DBIP");
		String DBPassword = prop.getProperty("DBPassword");
		String ServiceName=prop.getProperty("ServiceName");
		String DBport=prop.getProperty("DBport");
		String Cabinet=prop.getProperty("ImportcabinetName");
		Cabinet=Cabinet.toUpperCase();
	
		String DBUser = prop.getProperty("DBUser");
		int count = -1;
		Connection con=null;
		con=ConnectionManager.getConnection(DBUser, DBPassword,DBIP,DBport, ServiceName);
		Statement stmt = con.createStatement();
	
	
		/*String sql="select * from ReportMast";
		ResultSet rs=	stmt.executeQuery(sql);
		while (rs.next())
				{
					 count=rs.getInt(1);
					 System.out.println(count);
				}
		
		}*/
		String query="select dbms_metadata.get_ddl( 'TABLE', 'USR_0_STOPPAYMENTADVICE', 'SAMBA' ) from dual;"  ;
		ResultSet rs = stmt.executeQuery("select dbms_metadata.get_ddl( 'VIEW', 'V_USR_0_T16PSLFAX1', 'EQUITAS_ORACLE' ) from dual");
	
		String a=null;
		if (rs.next()) {
			a= rs.getString(1);
			System.out.println(a);
		}
		//System.out.println("Number of tables Faulty are "+faultlist);
		//File files = new File("C:/Users/vishal.verma/Desktop/Samba Newgen Migration Tool/Export");
		
		
	        OutputStream os = null;
	        try {
	            os = new FileOutputStream(new File("C:/Users/vishal.verma/Desktop/Samba Newgen Migration Tool/Export/checkos.txt"));
	            os.write(a.getBytes(), 0, a.length());
	            System.out.println("query executed");
	        } catch (IOException e) {
	            e.printStackTrace();
	        }finally{
	            try {
	                os.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	    }
		}



