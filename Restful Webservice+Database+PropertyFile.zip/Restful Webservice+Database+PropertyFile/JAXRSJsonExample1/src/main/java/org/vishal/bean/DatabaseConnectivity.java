package org.vishal.bean;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class DatabaseConnectivity {
	Connection connection=null;
	public Connection getConnection() {  
     //   Connection con=null;  
		Properties property=new Properties();
		FileInputStream fin;
		try {
			fin = new FileInputStream("D:/Projects/o2msWorkspace/JAXRSJsonExample1/DataBase.properties");
			try {
				property.load(fin);
			} catch (IOException e) {
				e.printStackTrace();
			}
			try {
				fin.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e1) {
			e1.printStackTrace();
		}
		
		
		String url= (String)property.getProperty("jdbc.url");
		String user= (String)property.getProperty("jdbc.user");
		String password= (String)property.getProperty("jdbc.password");
        try{  
        	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
              
            
        	connection=DriverManager.getConnection(url,user,password);
        	
        	System.out.println("connected");
        }catch(Exception e){System.out.println(e);}  
        return connection;  
    }  
}
