package org.vishal.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
//import java.util.HashMap;
import java.util.List;

import org.vishal.bean.Country;
import org.vishal.bean.DatabaseConnectivity;


public class CountryService {
	
	/*static HashMap<Integer, Country> countryIdmap= getCountry();
	
	private static HashMap<Integer, Country> getCountry(){
		return countryIdmap;
	}
	
	public CountryService(){
		super();
		
		if(countryIdmap==null){
			countryIdmap=new HashMap<Integer, Country>(); 
			
			countryIdmap.put(1,new Country(01, "India", 2018));
			countryIdmap.put(2,new Country(02, "America", 12345));
			countryIdmap.put(3,new Country(03, "Australia", 76421));
			countryIdmap.put(4,new Country(04, "London", 98765));
			countryIdmap.put(5,new Country(05, "Japan", 5678));
			
		}
	}*/
	Connection connect= new DatabaseConnectivity().getConnection();
	
	public List<Country> getAllCountries(){
		
		/*List<Country> countries=new ArrayList<Country>(countryIdmap.values());
		return countries;*/
		List<Country> countries=new ArrayList<Country>();
		try {
			PreparedStatement ps= connect.prepareStatement("select * from CountryData");
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				Country country=new Country();
				country.setId(rs.getInt(1));
				country.setCountryName(rs.getString(2));
				country.setPopulation(rs.getLong(3));
				countries.add(country);
			}
			connect.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return countries;
	}
	public Country getCountry(int id){
		/*Country country=countryIdmap.get(id);
		return country;*/
		Country country= new Country();
		try {
			PreparedStatement ps= connect.prepareStatement("select * from CountryData where id=?");
			ps.setInt(1, id );
			
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				
				country.setId(rs.getInt(1));
				country.setCountryName(rs.getString(2));
				country.setPopulation(rs.getLong(3));
				
			}
			rs.close();
			connect.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return country;
	}
	
	public Country addCountry(Country country) throws SQLException{
		//country.setId(countryIdmap.size()+1);
		/*countryIdmap.put(country.getId(), country);
		return country;*/
		PreparedStatement ps=connect.prepareStatement("insert into  CountryData(id,countryName,population) values(?,?,?);");
		ps.setInt(1, country.getId());
		ps.setString(2, country.getCountryName());
		ps.setLong(3, country.getPopulation());
		int status=ps.executeUpdate();
		System.out.println(status);
		ps.close();
		connect.close();
		return country;
	}
	/*public Country updateCountry(Country country){
		if(country.getId()<0) 
			return null;
		else{
			countryIdmap.put(country.getId(), country);
			return country;
		}
	}*/
	public int updateCountry(Country country) throws SQLException{
		if(country.getId()<0) 
			return 0;
		else{
		PreparedStatement ps=connect.prepareStatement("update CountryData set countryName=?, population=? where id=?");
		ps.setString(1, country.getCountryName());
		ps.setFloat(2, country.getPopulation());
		ps.setInt(3, country.getId());
		
		int status=ps.executeUpdate();
		connect.close();
		return status;
			}
	}
	public void deleteCountry(int id) throws SQLException{
		/*countryIdmap.remove(id);*/
		PreparedStatement ps=connect.prepareStatement("delete from CountryData where id=?");
		ps.setInt(1, id);
		
		int status=ps.executeUpdate();
		System.out.println(status);
		connect.close();
	}
	
}