package Logs;

import org.apache.log4j.Logger;
/*import org.apache.log4j.Appender;
import org.apache.log4j.FileAppender;
import org.apache.log4j.Layout;
import org.apache.log4j.PatternLayout;*/

public class FirstLogExample {
	static Logger l= Logger.getLogger(FirstLogExample.class.getName());
	
	public static void main(String args[]){
		/*Layout li= new PatternLayout();
		System.out.println("Testing");
		Appender a;
		try{
			a= new FileAppender(li, "Logs.txt", false);
			a= new FileAppender(li, "Logs.txt", true);
			l.addAppender(a);
			l.fatal("This is test  of  j");
		}catch(Exception e){
			l.fatal("Test the data here");
			e.printStackTrace();
		}*/
		
		l.debug("this is debug");
		l.fatal("this is fatal");
		l.error("this is error");
		l.info("this is Info");
		l.warn("this is warn");
		System.out.println("you have implemented Log4j");
	}
}
