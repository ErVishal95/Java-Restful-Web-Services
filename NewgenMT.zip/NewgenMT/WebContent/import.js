/*******************************************************************************************************************
 *	NEWGEN SOFTWARE TECHNOLOGIES LIMITED

 *	Group					: AP2
 *	Product / Project       : Template Migration Utility Tool
 *	File Name				: Migration Import Jquery File
 *	Author					: Vishal Verma
 *	Date written(DD/MM/YYYY): 15/05/2018
 *	Purpose					: Used for consuming ImportVerify and Import Webservice for getting Template List (Success and Failure) and for validation

 *****************************************************************************
 *	Change History:
 *****************************************************************************
 *	 SNo	Date	Change By		Change Description (Bug No. If Any) 
 ***************************************************************************************************************************/ 
	
	/*d3.csv("fruit.csv", function(error, data){
		if(error) {
			alert('Error in Config File!');
			return;
		}
	data = data.map(function(d){ d.value = +d["IP"]; return d; });
	ip=data[0].IP;	
	port=data[0].Port;
	localStorage.setItem("IPADDR", ip);
	localStorage.setItem("PORTNUM", port);
	});
	
	var Ipaddr = localStorage.getItem("IPADDR");
	//var Ipaddr = 'localhost';
	var PortNum = localStorage.getItem("PORTNUM");
	//var url = "http://"+Ipaddr+":"+PortNum+"/MigrationUtility/migration/exportVerify";
	//console.log("URL ADDR ",url);
	console.log("IP Address",localStorage.getItem("IPADDR"));
	
	console.log("Port Address",localStorage.getItem("PORTNUM"));
*/
	// Dynamic IP Address and Port Number END//

	var succeslist_arr = "";
    
	function showSuccessList(){
        // Export Button Popup Modal Start
		$('#export_btn').text(succeslist_arr);
        $("#myModal1").modal('show');    
		// Export Button Popup Modal End
    }
	
    function doFunction() {
	
		$("#myModal1").modal('hide');  	// Hide SuccessList Array Export Button Here
		
        //alert('Success List ' + succeslist_arr); 
        console.log(succeslist_arr);// The function returns the product of p1 and p2
		//var sList=JSON.stringify(succeslist_arr);
        //var myData = {"productNameArray": ["UNDERWRITERV2","HCCI_DO_VE_SC_V3"]};
        var textBoxString = $('#txtword').val();
        textBoxString = textBoxString.replace(/\\/gi, "/");
        console.log(textBoxString);
		var jString = '{ "productNameArray" : [';
		jString = jString.concat(succeslist_arr);
		jString = jString.concat(' ],"folderPath" :"');
		jString = jString.concat(textBoxString);
		jString = jString.concat('"}');
		//jString = jString.replace("\\\\", "/");
		console.log(jString);
		var finalJson = JSON.parse(jString); 
		//console.log(jString);
		console.log(finalJson);
		
		//var url = "http://"+Ipaddr+":"+PortNum+"/MigrationUtility/migration/import";
		var url = "http://127.0.0.1:9990/MigrationUtility/migration/import";
		console.log(url);
		 jQuery.ajax({
                type : "POST",
                url : url,
                async : false,
                cache : false,
               // timeout : 30000,
				contentType : "application/json; charset=utf-8",
                data : JSON.stringify(finalJson),
                dataType : "json",
                success : function(response) {
						
					var sLResponse=JSON.parse(JSON.stringify(response));
                    console.log("op3 "+JSON.stringify(sLResponse)); 
					
					//alert("Response : "+sLResponse.output);       // fatching the value of Export Folder path from key: "output"
					
					// Response success Popup Modal  
						//$("#myModal1").modal('hide');
						//var response = $('#response');      
						//exportbtn.html(sLResponse.output);
						$('#response').text(sLResponse.output)
						$("#myModal_2").modal('show');
					// Response success Popup Modal 
    			},
    			error: function (jqXHR, textStatus, errorThrown) {
                    alert("Service not consumed");
                    console.log(jqXHR.responseText + ' ' + errorThrown);
                }

		 });
    }
    $(function () {
    
    $('#btnCheck').click(function () {
    var textBoxString = $('#txtword').val();
    
    var filePath = textBoxString;
    var allowedExtensions = /(\.mdb)$/i;
	console.log(allowedExtensions);
	 textBoxString = textBoxString.replace(/\\/gi, "/");
	 
	 console.log(textBoxString);
	var strarray = textBoxString.split('/');
	console.log(strarray);
	var flag = 0;									//Validation for valid path - Must contain "Export" word for folder name in path
	for(i in strarray){
		if(strarray[i] ==="Export"){
			flag = 1;
			console.log("value of flag :"+flag);
		}
	}
	if (flag !== 1){
		//alert("Please Enter valid File Path !!");
		$("#myModal").modal('show');
	}
	
   /*  if(!textBoxString.includes("Export")){		//Validation for valid path - Must contain "Export" word for folder name in path
        alert("Please Enter valid File Path !!");
    	textBoxString = '';
    	return false;
    } */
    
   
    else if(!allowedExtensions.exec(filePath)){		//Validation for .mdb file extension - Must contain ".mdb" word for file extension in path
	
		$("#myModal").modal('hide');
        //alert('Please Provide File Name having extension .mdb !!');
		$("#myModal_1").modal('show');
        textBoxString = '';
        return false;
	}
	else{
   /*  var strarray = textBoxString.split(',');
    console.log("firstarray "+strarray); */
       
    var displayResources1 = $('#display-resources1');
   // displayResources1.text('Loading data from JSON source...');
    
    var displayResources = $('#display-resources');
    //displayResources.text('Loading data from JSON source...');
    
	var jsonArray = JSON.stringify(textBoxString);
	 console.log("jsonify firstarray "+jsonArray);
	 //var url = "http://"+Ipaddr+":"+PortNum+"/MigrationUtility/migration/importVerify";
	 var url = "http://127.0.0.1:9990/MigrationUtility/migration/importVerify";
	 console.log(url);
   var jsonString = '{ "folderPath" : ';
   jsonString = jsonString.concat(jsonArray);
   jsonString = jsonString.concat(' }');
   var parsedJson =JSON.parse(jsonString);
   console.log("the string after concatenation is " + jsonString);
  // console.log("parsed json: "+JSON.stringify(parsedJson));
   //alert('jsonString after concatenating is ' + jsonString);
     jQuery.ajax({
                type : "POST",
                url : url,
                async : false,
                cache : false,
               // timeout : 30000,
				contentType : "application/json; charset=utf-8",
                data : JSON.stringify(parsedJson),
                dataType : "json",
                success : function(response) {

                    console.log("json resonse "+JSON.stringify(response));
                    var pJson=JSON.parse(JSON.stringify(response));
                    console.log("op3 "+JSON.stringify(pJson));            
        // Print Success List Start
                    var array1= pJson['successList'];
            
                    for (var j=0;j<array1.length;j++)
                 	   {
                 	     console.log(array1[j]['productname']);
                 	   }  
                    var output="<table><thead><tr style='font-size: 20px;'><th>Product Name</th><tbody>";
                    for (var i in array1)
                    {
                    output+="<tr style='font-size: 20px;'><td>" + array1[i].productname + "</td></tr>";
                    }
                    output+="</tbody></table><form><button type='button' id='btn_successList' class='btn btn-primary'>Import</button></form>";
                    
                   
                    displayResources1.html(output);
                    $("table").addClass("table");
		// Print Success List End			
                    
        // Print Failure List Start            
                    var array= pJson['failureList'];
           
                    for (var i=0;i<array.length;i++)
                 	   {
                 	     console.log(array[i]['productname']);
                 	     
       
                 	   }   
                  
                    var output="<table><thead><tr style='font-size: 20px;'><th>Product Name</th><th>Description</th></thead><tbody>";
                    for (var i in array)
                    {
                    output+="<tr style='font-size: 20px;'><td>" + array[i].productname + "</td><td>" + array[i].description + "</td></tr>";
                    }
                    output+="</tbody></table>";
                   
                    displayResources.html(output);
                   
                    $("table").addClass("table");
			// Print Failure List End
				
			// Fatching Comma Sapatated Array of SuccessList start
                    succeslist_arr = "";
                    for (var i=0;i<array1.length;i++)
              	   {
              	     console.log(array1[i]['productname']);
             	   //	 succeslist_arr += array1[i]['productname'];
             	   	succeslist_arr += "\""+ array1[i]['productname']+ "\"";
             	  	if(i!==(array1.length -1))
              	   	succeslist_arr +=",";
              	   }  
            // Fatching Comma Sapatated Array of SuccessList End
				 
			// Calling Function showSuccessList for printing success list  on modal Start        
                    var el = document.getElementById("btn_successList");
                    if (el.addEventListener)
                        el.addEventListener("click", showSuccessList, false);
                    else if (el.attachEvent)
                        el.attachEvent('onclick', showSuccessList);
                
			// Calling Function showSuccessList for printing success list  on modal End
                    
            // Disabled Export Button if no data in SuccessList Start     
                   // console.table(array1.length);
                    console.log(array1.length);
                    if(array1.length == 0){
                		$('#btn_successList').attr("disabled", "disabled");
                	} 
                  
                    
			// Disabled Export Button if no data in SuccessList Start       
                   
                },
 
                error: function (jqXHR, textStatus, errorThrown) {
				//Error Modal showing server not connected Start	
                    if(jqXHR.responseText !== ''){
						//(jqXHR.responseText + ' ' + errorThrown);
						$("#myModal_3").modal('show');
					}	
                    console.log(jqXHR.responseText + ' ' + errorThrown);
                }
				//Error Modal showing server not connected End
            });
		}
    });
    
 
    
    })