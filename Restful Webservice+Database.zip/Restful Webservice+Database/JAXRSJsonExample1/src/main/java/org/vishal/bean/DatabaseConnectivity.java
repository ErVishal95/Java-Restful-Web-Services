package org.vishal.bean;

import java.sql.Connection;
import java.sql.DriverManager;

public class DatabaseConnectivity {
	Connection connection=null;
	public Connection getConnection(){  
     //   Connection con=null;  
        try{  
        	Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");  
            connection=DriverManager.getConnection("jdbc:localhost:8080;databaseName=DATABASENAME;user=USER;password=PASSWORD");  
            System.out.println("connected");
        }catch(Exception e){System.out.println(e);}  
        return connection;  
    }  
}
