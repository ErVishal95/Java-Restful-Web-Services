package WriteJSON;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.LinkedHashMap;

import javax.json.JsonArray;

import org.codehaus.jettison.json.JSONException;
import org.codehaus.jettison.json.JSONObject;
import org.json.simple.JSONArray;

public class JsonToFile {
	public static void main(String args[]) throws JSONException{
		
		JSONObject jo=new JSONObject();
		jo.put("First-Name", "Vishal");
		jo.put("Last-Name", "Verma");
		jo.put("Education", "B.Tech");
		jo.put("Profesion", "Software Engineer");
		
		HashMap hm=new LinkedHashMap(4);
		hm.put("House-Number", "J-123, 3rd floor");
		hm.put("City", "Delhi");
		hm.put("Pincode", "110052");
		hm.put("Country", "India");
		
		jo.put("Address", hm);
		
		JSONArray jr=new JSONArray();
		
		/*hm= new LinkedHashMap(2);
		hm.put("Type", "Mobile");
		hm.put("Number", "1234567890");
		jr.add(hm);*/
		
		JSONObject jObj = new JSONObject();
		jObj.put("Type", "Mobile");
		jObj.put("Number", "1234567890");
		jr.add(jObj);
		
		JSONObject jObj1 = new JSONObject();
		jObj1.put("Type", "Fax");
		jObj1.put("Number", "9867453210");
		jr.add(jObj1);
		
		jo.put("Telephone", jr);
	
		
		try {
			PrintWriter pw=new PrintWriter(new File("D:/Projects/webapplication/Restful webService with Database Connectivity/TestJson.json"));
			System.out.println(jo.toString());
			pw.write(jo.toString());
			pw.flush();
			pw.close();
		} catch (FileNotFoundException e) {
			
			e.printStackTrace();
		}
	}
}
