package ReadJSON;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class JsonfromFile {
 
	public static void main(String args[]) throws FileNotFoundException, IOException, ParseException {
		
		Object object=new JSONParser().parse(new FileReader("D:/Projects/webapplication/Restful webService with Database Connectivity/TestJson.json"));
		JSONObject jo= (JSONObject) object;
		jo.get("First-Name");
		jo.get("Last-Name");
		jo.get("Education");
		jo.get("Profesion");
		System.out.println(jo.get("First-Name"));
		System.out.println(jo.get("Last-Name"));
		System.out.println(jo.get("Education"));
		System.out.println(jo.get("Profesion"));
		
		Map address=(Map)jo.get("Address");
		 
		Iterator<Map.Entry> itr= address.entrySet().iterator();
		 while(itr.hasNext()){
			 Map.Entry pair=itr.next();
			 System.out.println(pair.getKey()+" : "+pair.getValue());
			 
		 }
		 
		 JSONArray jr=(JSONArray) jo.get("Telephone");
		 
		/* for(int i=0;i<jr.size();i++){
			 System.out.println(jr.get(i));

			  Map inner= (Map) jr.get(i);
			 Iterator<Object> iterator=inner.entrySet().iterator();
			    while(iterator.hasNext()){
			        Map.Entry<String, Object> entry=(Entry<String, Object>) iterator.next();
			        System.out.println("Key :"+entry.getKey()+" Value : "+entry.getValue());
			    }
		 }*/
		 
		 Iterator itr2=jr.iterator();
		 
		 while (itr2.hasNext()) 
	        {	
			 	Iterator itr1 = ((Map) itr2.next()).entrySet().iterator();
	            while (itr1.hasNext()) {
	                Map.Entry pair = (Entry) itr1.next();
	                System.out.println(pair.getKey() + " : " + pair.getValue());
	            }
	        }
		 for(int i = 0;i<jr.size();i++){
			 JSONObject map = (JSONObject)jr.get(i);
			 System.out.println("map :::: "+map);
			 Set set = map.keySet();
			 Iterator itr12=set.iterator();
			 while(itr12.hasNext()){
				 System.out.println("Actual value :::: "+map.get(itr12.next()));
			 }
		 }
	}
}
